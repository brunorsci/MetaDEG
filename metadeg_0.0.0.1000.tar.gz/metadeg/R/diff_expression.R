#'@title diff_expression.
#'@description
#'The function
#'@param counts a count matrix of gene expression.
#'@param metadata a experimental design with information about samples and comparation.
#'#'@param compare string with comparation for diferential expression.
#'@return A data frame with DEGs results
#'@author Bruno Rodrigo Assuncao(2024).
#'@export

diff_expression <- function(counts=counts_PRJNA178116, metadata=PRJNA178116_metadados, sample_col="sample", condition_col="condition", condition1, condition2) {
  
  
  # Merge counts and metadata
  combined_data <- merge(metadata, counts, by.x = sample_col, by.y = sample_col)
  rownames(combined_data) <- combined_data[, sample_col]
  
  # Filtrar as condições de interesse
  combined_data <- combined_data[combined_data[, condition_col] %in% c(condition1, condition2), ]
  
  # Preparar os dados de expressão e a matriz de design
  expr_data <- combined_data[, -which(colnames(combined_data) %in% c(sample_col, condition_col))]
  
  # Certifique-se de que condition é um fator com níveis definidos
  combined_data[, condition_col] <- factor(combined_data[, condition_col], levels = c(condition1, condition2))
  
  design <- model.matrix(~0 + combined_data[, condition_col])
  colnames(design) <- levels(combined_data[, condition_col])
  
  # Criar o objeto DGEList
  dge <- DGEList(counts = t(expr_data))
  
  # Calcular os fatores de normalização usando TMM
  dge <- calcNormFactors(dge)
  
  # Transformação voom, aplicando os fatores de normalização calculados
  v <- voom(dge, design)
  
  # Ajuste do modelo linear
  fit <- lmFit(v, design)
  contrast <- paste(condition2, "-", condition1, sep="")
  contrast.matrix <- makeContrasts(contrasts = contrast, levels = design)
  fit2 <- contrasts.fit(fit, contrast.matrix)
  fit2 <- eBayes(fit2)
  
  # Obter os resultados
  results <- topTable(fit2, adjust = "fdr", number = Inf)
  return(results)
}
