#'@title diff_expression.
#'@description
#'The function
#'@param counts a count matrix of gene expression.
#'@param metadata a experimental design with information about samples and comparation.
#'#'@param compare string with comparation for diferential expression.
#'@return A data frame with DEGs results
#'@author Bruno Rodrigo Assuncao(2024).
#'@export

diff_expression <- function(counts, metadata, compare="DiagnosisControl") {
  # Merge counts and metadata
  combined_data <- merge(metadata, counts, by = "SampleID")
  rownames(combined_data) <- combined_data$SampleID
  
  # Preparar os dados de expressão e a matriz de design
  expr_data <- combined_data[, grepl("Gene", colnames(combined_data))]
  design <- model.matrix(~ Diagnosis, data = combined_data)
  
  # Criar o objeto DGEList
  dge <- DGEList(counts = t(expr_data))
  
  # Normalização usando TMM
  dge <- calcNormFactors(dge)
  
  # Transformação voom
  v <- voom(dge, design)
  
  # Ajuste do modelo linear
  fit <- lmFit(v, design)
  fit <- eBayes(fit)
  
  # Obter os resultados
  results <- topTable(fit, coef = compare, adjust = "fdr", number = Inf)
  return(results)
}
